#!/bin/sh
./redis-server redis.conf
