#!/bin/sh
kill -9 $(pidof redis-server)
