#!/bin/sh
./sbin/nginx
